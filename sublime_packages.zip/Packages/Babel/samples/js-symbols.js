A = function() {}
B = function(z) {}
C = function c() {}
D = function d(z) {}
E = () => {}
F = (z) => {}
G = z => {}
function() {}
function(z) {}
function H() {}
function I(z) {}
() => {}
(z) => {}
J.prototype.j = () => {}
K.prototype.k = (z) => {}
L.prototype.l = z => {}
M.prototype.m = function() {}
N.prototype.n = function(z) {}
O.prototype.o = function oo() {}
P.prototype.p = function pp(z) {}
Q.q = () => {}
R.r = (z) => {}
S.s = z => {}
T.t = function() {}
U.u = function(z) {}
V.v = function vv() {}
W.w = function ww(z) {}

class X extends XX {}
class Y {}
