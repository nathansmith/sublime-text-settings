var a = b<cat()
var a = b < cat()
var a = b <cat[1]
var a = b < cat[1]
var a = b <cat?
var a = b <cat ?
var a = b < cat?
var a = b <cat===
var a = b < cat===
var a = b <cat&
var a = b < cat&&
var a = b <cat++
var a = b < cat++
var a = b <cat--
var a = b < cat--

var a = b <cat /*comment*/ />
var a = b <cat />
var a = b <cat/>
var a = b <cat-dog />
var a = b <cat-dog/>
var a = b <cat_dog />
var a = b <cat-dog />
var a = b <cat.dog />

var a = b <cat.dog/*comment*/ />
//
var a = b <cat- />
//
var a = b <cat. />
